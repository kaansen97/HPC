diary ex2.txt
read_csv_graphs
diary off