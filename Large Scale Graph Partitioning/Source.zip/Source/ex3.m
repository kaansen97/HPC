diary ex3.txt
Bench_bisection
diary off