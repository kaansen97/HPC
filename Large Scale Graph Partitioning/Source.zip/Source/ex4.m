diary ex4.txt
Bench_rec_bisection
diary off