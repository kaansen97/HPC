diary ex5.txt
Bench_metis(1)
diary off