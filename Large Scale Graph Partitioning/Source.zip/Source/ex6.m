diary ex6.txt
Bench_eigen_plot
diary off